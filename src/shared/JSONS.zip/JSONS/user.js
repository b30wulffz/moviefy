export default {
	users: [
		{
			"user_id": 1,
			"first_name": "Daniel",
			"last_name": "Radcliffe",
			"age": 26,
			"profile_pic": "<any image url>"			
		},
		{
			"user_id": 2,
			"first_name": "Jodie",
			"last_name": "Foster",
			"age": 60,
			"profile_pic": "<image url>"			
		},
		{
			"user_id": 3,
			"first_name": "Anthony",
			"last_name": "Hopkins",
			"age": 70,
			"profile_pic": "<image url>"			
		},
		{
			"user_id": 4,
			"first_name": "Emma",
			"last_name": "Watson",
			"age": 26,
			"profile_pic": "<image url>"			
		},
		{
			"user_id": 5,
			"first_name": "John",
			"last_name": "Doe",
			"age": 30,
			"profile_pic": "<image url>"			
		},
	]
} 

export default {
	"user_ratings": [
		{
			"user_id": 1,
			"ratings": [
				{
					"movie_id": 2,
					"ratings": 4
				},
				{
					"movie_id": 2,
					"ratings": 5
				},
				{
					"movie_id": 3,
					"ratings": 1
				},
				{
					"movie_id": 5,
					"ratings": 3
				}
			]
		},
		{
			"user_id": 2,
			"ratings": [
				{
					"movie_id": 4,
					"ratings": 4
				},
				{
					"movie_id": 2,
					"ratings": 5
				}
			]
		},
	]
}
